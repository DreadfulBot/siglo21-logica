#include <iostream>
#include <limits>

#include "GeometryCalculator.h"
using namespace RiskyWorks;

int main()
{
  GeometryCalculator calculator;
  calculator.execute();

  return 0;
}